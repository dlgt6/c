# C_NSW4I 功能块分析报告

## 基本信息

| 项目 | 内容 |
|------|------|
| 功能块名称 | C_NSW4I |
| 功能描述 | Numerical Changeover Switch, 4 Branch Selector(INT type)（数值切换开关，4分支选择器，INT类型） |
| 最后修改 | 2017.10.12 |
| 作者 | Hu Jing Qi |
| 页数 | 2页 |

## 功能概述

C_NSW4I 是一个4分支数值切换开关功能块，用于根据开关设置选择四个INT类型输入值中的一个。该功能块支持优先级选择，I1优先级最高，I2次之，I3再次，I4最低。

## 思维导图

```mermaid
graph TD
    A[C_NSW4I 4分支切换开关] --> B[输入模块]
    A --> C[处理模块]
    A --> D[输出模块]
    
    B --> B1[I1]
    B --> B2[I2]
    B --> B3[I3]
    B --> B4[I4]
    
    C --> C1[分支1选择]
    C --> C2[分支2选择]
    C --> C3[分支3选择]
    C --> C4[分支4选择]
    C --> C5[默认输出]
    
    D --> D1[Y]
    
    B1 --> C1
    B2 --> C1
    B2 --> C2
    B3 --> C2
    B3 --> C3
    B4 --> C3
    B4 --> C4
    B4 --> C5
    C1 --> D1
    C2 --> D1
    C3 --> D1
    C4 --> D1
    C5 --> D1
    
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style C fill:#e1ffe1
    style D fill:#ffe1e1
```

## 流程路径描述

### 分支1选择路径：
开始 → I1 = TRUE → 选择X1 → 输出Y
**功能**: 选择分支1输入值

### 分支2选择路径：
开始 → I1 = FALSE AND I2 = TRUE → 选择X2 → 输出Y
**功能**: 选择分支2输入值

### 分支3选择路径：
开始 → I1 = FALSE AND I2 = FALSE AND I3 = TRUE → 选择X3 → 输出Y
**功能**: 选择分支3输入值

### 分支4选择路径：
开始 → I1 = FALSE AND I2 = FALSE AND I3 = FALSE AND I4 = TRUE → 选择X4 → 输出Y
**功能**: 选择分支4输入值

### 默认输出路径：
开始 → I1 = FALSE AND I2 = FALSE AND I3 = FALSE AND I4 = FALSE → 输出0.1
**功能**: 默认输出0.1

## 逐帧功能分析

### Rung 7-10: 分支选择

**功能描述**: 根据开关设置选择相应的输入值

**输入条件**:
| 信号名称 | 信号描述 | 信号类型 | 触发值 |
|----------|----------|----------|--------|
| I1 | 分支1开关设置（优先级1） | BOOL | TRUE/FALSE |
| I2 | 分支2开关设置（优先级2） | BOOL | TRUE/FALSE |
| I3 | 分支3开关设置（优先级3） | BOOL | TRUE/FALSE |
| I4 | 分支4开关设置（优先级4） | BOOL | TRUE/FALSE |
| X1 | 分支1输入 | INT | 数值 |
| X2 | 分支2输入 | INT | 数值 |
| X3 | 分支3输入 | INT | 数值 |
| X4 | 分支4输入 | INT | 数值 |

**输出功能**:
| 信号名称 | 信号描述 | 信号类型 |
|----------|----------|----------|
| Y | 输出 | INT |

**触发逻辑**:
- IF I1 = TRUE THEN Y = X1
- IF I1 = FALSE AND I2 = TRUE THEN Y = X2
- IF I1 = FALSE AND I2 = FALSE AND I3 = TRUE THEN Y = X3
- IF I1 = FALSE AND I2 = FALSE AND I3 = FALSE AND I4 = TRUE THEN Y = X4
- ELSE Y = 0.1

**功能实现**: 
使用MOVE功能块，根据I1、I2、I3、I4的开关状态，选择相应的输入值输出到Y。当所有开关都为FALSE时，输出默认值0.1。

## 触发条件总结

### 选择条件
- **分支1选择**: I1 = TRUE
- **分支2选择**: I1 = FALSE AND I2 = TRUE
- **分支3选择**: I1 = FALSE AND I2 = FALSE AND I3 = TRUE
- **分支4选择**: I1 = FALSE AND I2 = FALSE AND I3 = FALSE AND I4 = TRUE
- **默认输出**: I1 = FALSE AND I2 = FALSE AND I3 = FALSE AND I4 = FALSE

## 实现功能总结

### 主要功能
1. **分支1选择**: 选择分支1输入值
2. **分支2选择**: 选择分支2输入值
3. **分支3选择**: 选择分支3输入值
4. **分支4选择**: 选择分支4输入值
5. **默认输出**: 当所有开关都为FALSE时输出默认值

## 关键信号说明

| 信号名称 | 信号描述 | 信号类型 | 用途 |
|----------|----------|----------|------|
| I1 | 分支1开关设置（优先级1） | BOOL | 分支1选择 |
| I2 | 分支2开关设置（优先级2） | BOOL | 分支2选择 |
| I3 | 分支3开关设置（优先级3） | BOOL | 分支3选择 |
| I4 | 分支4开关设置（优先级4） | BOOL | 分支4选择 |
| X1 | 分支1输入 | INT | 分支1输入值 |
| X2 | 分支2输入 | INT | 分支2输入值 |
| X3 | 分支3输入 | INT | 分支3输入值 |
| X4 | 分支4输入 | INT | 分支4输入值 |
| Y | 输出 | INT | 选择输出值 |

## 调试技巧

### 调试步骤
1. 检查I1、I2、I3、I4信号，确认开关设置
2. 检查X1、X2、X3、X4值，确认输入值
3. 监控Y值，观察选择输出

### 常见问题
1. **选择不正确**: 检查I1、I2、I3、I4开关设置
2. **输出不正确**: 检查X1、X2、X3、X4输入值

### 监控信号列表
- I1、I2、I3、I4（开关设置）
- X1、X2、X3、X4（输入值）
- Y（输出）
